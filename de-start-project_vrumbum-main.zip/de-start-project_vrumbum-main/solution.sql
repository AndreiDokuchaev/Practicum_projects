-- Этап 1. Создание и заполнение БД

create schema if not exists raw_data;

create table if not exists raw_data.sales (
-- хранение не больших целых чисел
    id int4,
-- строки переменной длины с ограничением 
    auto varchar(50),
-- числа с переменной точностью
    gasoline_consumption float4,
-- числа с переменной точностью
    price float4,
-- хранение даты в строке
    date varchar(50),
-- строки переменной длины с ограничением
    person_name varchar(50),
-- строки переменной длины с ограничением
    phone varchar(50),
-- целые числа
    discount smallint,
-- строки переменной длины с ограничением
    brand_origin varchar(50)
);

\copy raw_data.sales from 'c:\temp\cars.csv' with NULL AS 'null' csv header;

-- создание таблицы приведённой к 1НФ
create table raw_data.temp_data (
	id serial primary key,
	brand varchar,
	model varchar,
	color varchar,
	gasoline_consumption float4,
	price float4,
	date varchar,
	first_name varchar,
	last_name varchar,
	phone varchar,
	discount int,
	brand_origin varchar	
);

-- заполнение данными промежуточной таблицы с атомарными значениями
insert into raw_data.temp_data 
(brand, model, color, gasoline_consumption, price, date, first_name, last_name, phone, discount, brand_origin) 
select 
    split_part(auto, ' ', 1),
    substr(split_part(auto, ',', 1), strpos(split_part(auto, ',', 1), ' ') + 1),
    split_part(auto, ' ', -1),
    gasoline_consumption,
    price,
    date,
    split_part(person_name, ' ', 1),
    split_part(person_name, ' ', 2),
    phone,
    discount,
    brand_origin
from raw_data.sales;

-- создание схемы магазина
create schema if not exists car_shop;

-- создание таблиц приведённых к 3НФ
create table car_shop.colors (
	id serial primary key,
	color varchar(50) unique not null
);

-- создание таблиц приведённых к 3НФ
create table car_shop.countrys (
	id serial primary key,
	country varchar(50) unique not null
);

-- создание таблиц приведённых к 3НФ
create table car_shop.clients (
	id serial primary key,
	first_name varchar(50) not null,
	last_name varchar(50) not null,
	phone varchar(50) not null,
	unique(first_name, last_name, phone)
);

-- создание таблиц приведённых к 3НФ
create table car_shop.brands (
	id serial primary key,
	brand varchar(50) unique not null,
	country_id int references car_shop.countrys (id)
);

-- создание таблиц приведённых к 3НФ
create table car_shop.models (
	id serial primary key,
	model varchar(50) unique not null,
	gasoline_consumption varchar(50),
	brand_id int references car_shop.brands (id)
);

-- создание таблиц приведённых к 3НФ
create table car_shop.cars (
	id serial primary key,
	model_id int references car_shop.models (id),
	color_id int references car_shop.colors (id)
);

-- создание таблиц приведённых к 3НФ
create table car_shop.sales (
	id serial primary key,
	client_id int references car_shop.clients (id),
	car_id int references car_shop.cars (id),
	price float4 not null,
	date varchar(50) not null,
	discount int4 default 0
);

-- заполнение таблиц созданных ранее данными из промежуточной таблицы

-- таблица цветов
insert into car_shop.colors (color)
select distinct color from raw_data.temp_data;

-- таблица стран
insert into car_shop.countrys (country)
select distinct brand_origin from raw_data.temp_data
where brand_origin is not null;

--таблица клиентов
insert into car_shop.clients (first_name, last_name, phone)
select first_name, last_name, phone from raw_data.temp_data
on conflict do nothing;

--таблица брендов
insert into car_shop.brands (brand)
select distinct brand from raw_data.temp_data;

update car_shop.brands as b
set country_id = c.id
from car_shop.countrys c 
join raw_data.temp_data t on c.country = t.brand_origin
where b.brand = t.brand;

-- таблица моделей автомобилей
insert into car_shop.models (model, gasoline_consumption)
select model, gasoline_consumption from raw_data.temp_data
on conflict do nothing;

update car_shop.models m 
set brand_id = b.id
from car_shop.brands b join
raw_data.temp_data td on b.brand = td.brand 
where m.model = td.model;

-- таблица машин (модель + цвет)
insert into car_shop.cars (color_id, model_id)
select distinct c.id, m.id
from car_shop.colors c 
join raw_data.temp_data td on c.color = td.color 
join car_shop.models m on td.model = m.model;

-- таблица проданных машин
insert into car_shop.sales (price, date, discount) 
select price, date, discount from raw_data.temp_data;

update car_shop.sales s
set client_id = c.id
from car_shop.clients c
join raw_data.temp_data td on c.first_name = td.first_name and c.last_name = td.last_name
where s.price = td.price;

update car_shop.sales s 
set car_id = c.id
from car_shop.cars c
join car_shop.models m on c.model_id = m.id
join car_shop.colors co on c.color_id = co.id
join raw_data.temp_data td on m.model = td.model and co.color = td.color
where s.id = td.id and (m.model = td.model and co.color = td.color);

-- Этап 2. Создание выборок

---- Задание 1. Напишите запрос, который выведет процент моделей машин, у которых нет параметра `gasoline_consumption`.

select (SUM(CASE WHEN m.gasoline_consumption is null THEN 1 ELSE 0 END) * 100.0) / COUNT(s.car_id)
as nulls_percentage_gasoline_consumption 
from car_shop.sales s
join car_shop.cars c on s.car_id = c.id
join car_shop.models m on c.model_id = m.id;

---- Задание 2. Напишите запрос, который покажет название бренда и среднюю цену его автомобилей в разбивке по всем годам с учётом скидки.

select b.brand, 
date_part('year', s.date::date) as  year, 
round(avg(s.price::numeric), 2) price_avg
from car_shop.sales s 
join car_shop.cars c on s.car_id = c.id 
join car_shop.models m on c.model_id = m.id 
join car_shop.brands b on m.brand_id = b.id 
group by b.brand, date_part('year', s.date::date) 
order by b.brand, date_part('year', s.date::date);

---- Задание 3. Посчитайте среднюю цену всех автомобилей с разбивкой по месяцам в 2022 году с учётом скидки.

select 
month, 
date_part('year', s.date::date) as year, 
round(avg(s.price::numeric), 2) price_avg
from generate_series(1, 12, 1) as month
left join car_shop.sales s on date_part('month', s.date::date) = month
where date_part('year', s.date::date) = 2022
group by month, year
order by month;

---- Задание 4. Напишите запрос, который выведет список купленных машин у каждого пользователя.

select 
(c.first_name || ' ' || c.last_name) as person,
string_agg(b.brand || ' '|| m.model, ', ') cars
from car_shop.sales s 
join car_shop.clients c on s.client_id = c.id 
join car_shop.cars ca on s.car_id = ca.id 
join car_shop.models m on ca.model_id = m.id 
join car_shop.brands b on m.brand_id = b.id 
group by person
order by person;

---- Задание 5. Cамая большая и самая маленькая цена продажи автомобиля с разбивкой по стране без учёта скидки.

select co.country brand_origin, 
max(round(s.price::numeric * 100/(100 - s.discount), 2)), 
min(round(s.price::numeric * 100/(100 - s.discount), 2))
from car_shop.sales s 
join car_shop.cars c on s.car_id = c.id 
join car_shop.models m on c.model_id = m.id 
join car_shop.brands b on m.brand_id = b.id 
join car_shop.countrys co on b.country_id = co.id
group by brand_origin;

---- Задание 6. Напишите запрос, который покажет количество всех пользователей из США.

select count(*) persons_from_usa_count from car_shop.clients c
where c.phone like '+1%';
